public interface Describable {
    void displayDetails();  // Abstract method for displaying details
}
